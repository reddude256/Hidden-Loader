using System;

internal enum MouseState : byte
{
	None,
	Over,
	Down,
	Block
}